/**************************************/
/* Description : SEV config file .c   */
/* Author      : Abo elnour           */
/* Version     : 0.1v                 */
/* Date        : 2 Dec 2022           */
/* History     : 0.1v initial creation*/
/**************************************/
#include "STD_Types.h"

#include "DIO.h"

#include "SEV_cfg.h"
#include "SEV_priv.h"

tstrconfigSet  SEV_strConfigSet[SEV_MAX_NUM]=
{   
	{
		{
			/* A                B               C           */ 
			DIO_PIN_NUM_16 , DIO_PIN_NUM_17 , DIO_PIN_NUM_18  ,
			/* D                E               F           */ 
			DIO_PIN_NUM_19  , DIO_PIN_NUM_20 , DIO_PIN_NUM_21  ,
			/* G                                           */ 
			DIO_PIN_NUM_22  
		},
		
		DIO_PIN_NUM_24 ,
		
		COMMON_ANODE
	},
	{
		{
			/* A                B               C           */ 
			DIO_PIN_NUM_16 , DIO_PIN_NUM_17 , DIO_PIN_NUM_18  ,
			/* D                E               F           */
			DIO_PIN_NUM_19  , DIO_PIN_NUM_20 , DIO_PIN_NUM_21  ,
			/* G                                           */
			DIO_PIN_NUM_22
		},
		
		DIO_PIN_NUM_25 ,
		
		COMMON_ANODE
	}
	
};









