/*
 * main.c
 *
 *  Created on: Dec 2, 2022
 *      Author: nadin
 */
#include "STD_Types.h"
#include "BIT_Math.h"
#define F_CPU 8000000ul
#include <util/delay.h>

#include "LED.h"
#include "SEV.h"

int main(void)
{
	//FIRST PROJECT
	/*uint16 selector=0,counter=0,num1=9,num2=0,state=0;
    DIO_voidInit();
	while(1)
	{

        if(counter==1000)
		{
		if(state==0)
		{
			num1--;
			num2++;
		
		}
		else if(state==1)
		{
			num1++;
			num2--;
		}
		if((num2==9)&&(num1==0))
		{
			state=1;
			
		}
		else if((num2==0)&&(num1==9))
		{
			state=0;
		}
		counter=0;
		}
		if(selector==0)
		{
			SEV_enuDisplay(0,num1);
			DIO_enuWritePin(DIO_PIN_NUM_24,DIO_LOW);
			
			DIO_enuWritePin(DIO_PIN_NUM_25,DIO_HIGH);
			
			selector=1;
		}
		else
		{
			SEV_enuDisplay(1,num2);

			DIO_enuWritePin(DIO_PIN_NUM_25,DIO_LOW);
			
			DIO_enuWritePin(DIO_PIN_NUM_24,DIO_HIGH);
			
			
			selector=0;
		}
		counter++;
		_delay_ms(1);
	}*/
	//SECOND PROJECT
	/*sint32 counter=0;
	uint8 selector=0,num1=30;
    DIO_voidInit();
	LED_enuWrite(LED_1,LED_HIGH);
	while(1)
	{
		if(counter==30000)
		{
			LED_enuWrite(LED_1,LED_LOW);
			LED_enuWrite(LED_0,LED_HIGH);
			
		}
		else if(counter==60000)
		{
			LED_enuWrite(LED_0,LED_LOW);
			LED_enuWrite(LED_1,LED_HIGH);
			
		}
		else if(counter==90000)
		{
			LED_enuWrite(LED_1,LED_LOW);
			LED_enuWrite(LED_2,LED_HIGH);
			
		}
		else if(counter==120000)
		{
			LED_enuWrite(LED_2,LED_LOW);
			LED_enuWrite(LED_1,LED_HIGH);
			counter=0;
		}
		if(num1==0)
		{
			num1=30;
		}
		if(!(counter%1000))
		{
			num1--;
		}
		if(selector==0)
		{
			SEV_enuDisplay(0,num1%10);
			DIO_enuWritePin(DIO_PIN_NUM_24,DIO_LOW);
			
			DIO_enuWritePin(DIO_PIN_NUM_25,DIO_HIGH);
			
			selector=1;
		}
		else
		{
			SEV_enuDisplay(1,num1/10);

			DIO_enuWritePin(DIO_PIN_NUM_25,DIO_LOW);
			
			DIO_enuWritePin(DIO_PIN_NUM_24,DIO_HIGH);
			
			
			selector=0;
		}
		 counter++;
		 			_delay_ms(1);
	}*/
    //SECOND PROJECT
	uint8 counter=0;
    DIO_voidInit();
	LED_enuWrite(LED_0,LED_HIGH);
	LED_enuWrite(LED_7,LED_HIGH);
	while(1)
	{
	if(counter==0)
	{
		LED_enuWrite(LED_1,LED_HIGH);
		LED_enuWrite(LED_6,LED_HIGH);
		counter++;
	}
	else if(counter==1)
	{
		LED_enuWrite(LED_2,LED_HIGH);
		LED_enuWrite(LED_5,LED_HIGH);
		counter++;
	}
	else if(counter==2)
	{
		LED_enuWrite(LED_3,LED_HIGH);
		LED_enuWrite(LED_4,LED_HIGH);
		counter++;
	}
	else if(counter==3)
	{
		LED_enuWrite(LED_3,LED_LOW);
		LED_enuWrite(LED_4,LED_LOW);
		counter++;
	}
	else if(counter==4)
	{
		LED_enuWrite(LED_2,LED_LOW);
		LED_enuWrite(LED_5,LED_LOW);
		counter++;
	}
	else if(counter==5)
	{
		LED_enuWrite(LED_1,LED_LOW);
		LED_enuWrite(LED_6,LED_LOW);
		counter=0;
	}
	
      _delay_ms(1000);
	}
	return 0;
}
