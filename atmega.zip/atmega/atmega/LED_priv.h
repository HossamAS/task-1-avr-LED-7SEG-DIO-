/**************************************/
/* Description : LED private c File   */
/* Author      : hossam               */
/* Version     : 0.1V                 */
/* Date        : 01:38:39  09 Dec 2022*/
/* History     : 0.1V Initial Creation*/
/**************************************/




#ifndef LED_PRIV_H
#define LED_PRIV_H








#endif