/**************************************/
/* Description : DIO cfg file         */
/* Author      : Abo elnour           */
/* Version     : 0.1v                 */
/* Date        : 2 Dec 2022           */
/* History     : 0.1v initial creation*/
/**************************************/
#ifndef DIO_CFG_H
#define DIO_CFG_H

#define DIO_PIN_DIR_0     DIO_OUTPUT
#define DIO_PIN_DIR_1     DIO_OUTPUT
#define DIO_PIN_DIR_2     DIO_OUTPUT
#define DIO_PIN_DIR_3     DIO_INPUT
#define DIO_PIN_DIR_4     DIO_INPUT
#define DIO_PIN_DIR_5     DIO_INPUT
#define DIO_PIN_DIR_6     DIO_INPUT
#define DIO_PIN_DIR_7     DIO_INPUT
 
#define DIO_PIN_DIR_8     DIO_INPUT
#define DIO_PIN_DIR_9     DIO_INPUT
#define DIO_PIN_DIR_10    DIO_INPUT
#define DIO_PIN_DIR_11    DIO_INPUT
#define DIO_PIN_DIR_12    DIO_INPUT
#define DIO_PIN_DIR_13    DIO_INPUT
#define DIO_PIN_DIR_14    DIO_INPUT
#define DIO_PIN_DIR_15    DIO_INPUT

#define DIO_PIN_DIR_16    DIO_OUTPUT
#define DIO_PIN_DIR_17    DIO_OUTPUT
#define DIO_PIN_DIR_18    DIO_OUTPUT
#define DIO_PIN_DIR_19    DIO_OUTPUT
#define DIO_PIN_DIR_20    DIO_OUTPUT
#define DIO_PIN_DIR_21    DIO_OUTPUT
#define DIO_PIN_DIR_22    DIO_OUTPUT
#define DIO_PIN_DIR_23    DIO_INPUT
 
#define DIO_PIN_DIR_24    DIO_OUTPUT
#define DIO_PIN_DIR_25    DIO_OUTPUT
#define DIO_PIN_DIR_26    DIO_INPUT
#define DIO_PIN_DIR_27    DIO_INPUT
#define DIO_PIN_DIR_28    DIO_INPUT
#define DIO_PIN_DIR_29    DIO_INPUT
#define DIO_PIN_DIR_30    DIO_INPUT
#define DIO_PIN_DIR_31    DIO_INPUT



#endif