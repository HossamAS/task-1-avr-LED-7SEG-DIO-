/**************************************/
/* Description : LED header File      */
/* Author      : hossam               */
/* Version     : 0.1V                 */
/* Date        : 23:36:34  08 Dec 2022*/
/* History     : 0.1V Initial Creation*/
/**************************************/

#include "DIO.h"


#ifndef LED_H
#define LED_H
#define LED_0   DIO_PIN_NUM_0
#define LED_1   DIO_PIN_NUM_1
#define LED_2   DIO_PIN_NUM_2
#define LED_3   DIO_PIN_NUM_3
#define LED_4   DIO_PIN_NUM_4
#define LED_5   DIO_PIN_NUM_5
#define LED_6   DIO_PIN_NUM_6
#define LED_7   DIO_PIN_NUM_7

#define LED_HIGH DIO_HIGH
#define LED_LOW  DIO_LOW


tenuErrorStatus LED_enuWrite(uint8 u8PinNumCpy,uint8 u8PinValueCpy);

#endif