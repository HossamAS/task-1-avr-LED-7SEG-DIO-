/****************************************/
/* Description : LED private header File*/
/* Author      : hossam                 */
/* Version     : 0.1V                   */
/* Date        : 01:38:39  09 Dec 2022  */
/* History     : 0.1V Initial Creation  */
/****************************************/
