/**************************************/
/* Description : LED c File           */
/* Author      : hossam               */
/* Version     : 0.1V                 */
/* Date        : 23:36:34  08 Dec 2022*/
/* History     : 0.1V Initial Creation*/
/**************************************/
#include "STD_Types.h"
#include "DIO.h"
#include "LED.h"
#include "LED_cfg.h"
#include "LED_priv.h"


tenuErrorStatus LED_enuWrite(uint8 u8PinNumCpy,uint8 u8PinValueCpy)
{
	return DIO_enuWritePin(u8PinNumCpy,u8PinValueCpy);
}